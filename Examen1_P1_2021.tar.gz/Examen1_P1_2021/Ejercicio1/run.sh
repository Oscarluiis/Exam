#!/bin/bash

EASYASM="EasyASM"
$EASYASM --run easm_crt.asm main.asm triangle.asm
