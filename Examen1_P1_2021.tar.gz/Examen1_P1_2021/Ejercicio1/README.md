# TODO

Implementar la funcion draw_triangle utilizando ensamblador
MIPS32. El prototipo es el siguiente:

void draw_triangle(int h)

El argumento especifica la altura del triangulo que
la funcion debera dibujar utilizando asteriscos.

# Ejemplos

Para h = 3
  *
 * *
*****

Para h = 4
   *
  * *
 *   *
*******

# Prueba del programa

Para probar el ejercicio puede correr el script
test.sh el cual mostrara un mensaje Passed o Failed
dependiendo de si el ejercicio funciona o no funciona
correctamente.
Tambuien puede utilizar el script run.sh para correr el programa

La funcion debera ser implementada en el archivo triangle.asm
